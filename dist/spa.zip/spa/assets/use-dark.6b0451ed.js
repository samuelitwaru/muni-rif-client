import{n as e}from"./index.1080353d.js";const u={dark:{type:Boolean,default:null}};function n(a,r){return e(()=>a.dark===null?r.dark.isActive:a.dark)}export{u as a,n as u};
