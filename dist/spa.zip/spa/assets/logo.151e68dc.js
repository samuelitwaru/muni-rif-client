var s="/assets/logo.7ab435e4.jpeg";export{s as _};
