import{V as a,aX as r}from"./index.1080353d.js";function u(){return a(r)}export{u};
