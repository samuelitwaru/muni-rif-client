import{api as t}from"./axios.8558e732.js";async function s(){return(await t.get("calls/")).data}async function r(){return(await t.get("themes/")).data}export{s as a,r as g};
